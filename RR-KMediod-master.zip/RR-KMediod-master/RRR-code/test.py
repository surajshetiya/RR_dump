import basestuff
from basestuff import *
import KsetEnum
from KsetEnum import *
from MDRC import MDRC
from MD import MDRRR
import MD
import HDRR
from time import time
import twoD

folder = 'data/'
filename = 'DOTDec2017'
columns = [10,11,16,13,19,20,12,14]


r = 5; n=100;gamma=4;
setparams(100,4,K=5);
genData(file=folder+filename+'.csv',pythonfile=False,cols=columns[0:3])

Kset_random()
# print basestuff.top_k([1,1])
t = time()
S1 = MDRC()
print time()-t
print S1
S = twoD.twoDRRR()
print S
print MD.maxk_rand(S1,100)
print twoD.maxk(S1)
print MD.maxk_rand(S,100)
print twoD.maxk(S)
'''
s = MDRRR()
print s
s2 = HDRR.DMM(len(s),gamma)
print s2
print MD.maxk_rand(set(s2),100)
'''

#Kset_Enum()

#print len(KsetEnum.Ksets)
#print KsetEnum.Ksets