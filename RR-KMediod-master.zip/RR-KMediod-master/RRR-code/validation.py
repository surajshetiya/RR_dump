import basestuff
from basestuff import *
import MD
from MD import *
from time import time
import HDRR
import MDRC

folder = 'data/'
filename = 'BN-2-21-2018-n116300'
columns = [14, 18, 20, 19, 21] # Carat: 14, Depth: 18, Price: 20, LengthWidthRatio: 19, Table: 21
conversion = [2.51, 80, -13829, 2.75, 85]

gamma=6; m=5; k=20; n = 1000;#16300;

def convert(i):
    global m, conversion;
    tmp = np.zeros(m)
    for j in range(m):
        if conversion[j]>0: tmp[j] = basestuff.dataset[i][j]*conversion[j]
        else: tmp[j] = (basestuff.dataset[i][j]-1)*conversion[j]
    return tmp


#gamma=6; n = 1000; m=3; k=3
setparams(n,m,K=k)
genData(file=folder+filename+'.csv',pythonfile=False,cols=columns[0:m])
print '--------------RRR--------------'
s1 = MDRC.MDRC()
print 'len(s1): ', len(s1)
for i in s1: print i
for i in s1:
    print convert(i)
print '--------------RegretRatio--------------'
s2 = HDRR.DMM(100,gamma)
print 'len(s2): ', len(s2)
for i in s1: print i
for i in s2:
    print convert(i)