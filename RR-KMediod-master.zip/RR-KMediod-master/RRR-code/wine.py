import basestuff
from basestuff import *
import twoD
from twoD import *
import MD
from time import time

folder = 'data/'
filename = 'Wine'
columns = columns = [3,6,5] # Carat: 14, Depth: 18, LengthWidthRatio: 19, Table: 21, Price: 20

n = 100; m=2
st=''
setparams(n,2,K=1);
genData(file=folder+filename+'.csv',pythonfile=False,cols=columns[0:2])
t = time()
s1 = twoDRRR()
st+= ',' + str(time()-t)
print s1
t = time()
twoD.FindRanges(findksets=True)
t1 = time()-t
s2 = MD.MDRRR(ksets = list(twoD.ksets))
t2 = time()-t
print s2[0]
t3 = t2-t1
st+= ',' + str(t1)+',' + str(t3)+',' + str(t2)
st+= ',' + str(len(s1)) + ',' + str(len(s2))
st+= ',' + str(maxk(s1))+ ',' + str(len(twoD.ksets))
print st
#basestuff.mylog(st,'results/BNtwoDVK.csv')